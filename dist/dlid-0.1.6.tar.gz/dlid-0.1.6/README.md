# DLID
A small Python Deep Learning library used to learn DL with the book online.

## Installation
```python
from dlid import data
```